
package evs;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class Evs implements ActionListener{
    // THE VERY FIRST SCREEN
    JButton badmin,bcandidate,bvoter;
      
    public void firstframe()
    { 
        JFrame f= new JFrame("E-VOTING SYSTEM");
        JPanel jp= new JPanel ();
        jp.setBackground( new Color(160,186,101));
        jp.setBounds(57, 90, 500,500);
        JLabel jl =new JLabel("YOU WANT TO LOGIN AS:");
        jl.setFont(new Font("Ariel Black",Font.BOLD,15));
       
        
         //ADMIN BUTTON
       badmin= new JButton("ADMIN");
       badmin.setBounds(155,183,300, 40);
       badmin.setFont(new Font("Ariel Black",Font.BOLD,16));
       badmin.setBackground(Color.yellow);
       badmin.setFocusable(false);
       badmin.addActionListener(this);
       
       //CANDIDATE BUTTON
       bcandidate= new JButton("CANDIDATE");
       bcandidate.setBounds(155, 264, 300, 40);
       bcandidate.setFont(new Font("Ariel Black",Font.BOLD,16));
       bcandidate.setBackground(Color.PINK);
       bcandidate.setFocusable(false);
       bcandidate.addActionListener(this);
       
        //VOTER BUTTON
       bvoter= new JButton("VOTER ");
       bvoter.setBounds(155, 343, 300, 40);
       bvoter.setFont(new Font("Ariel Black",Font.BOLD,16));
       bvoter.setBackground(Color.CYAN);
       bvoter.setFocusable(false);
       bvoter.addActionListener(this);
      
      
       
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       f.setSize(800, 800);
       f.setLayout(null);
       f.setResizable(false);
       f.add(jp);
       jp.add(jl);
       f.add(badmin);
       f.add(bcandidate);
       f.add(bvoter);
       f.setVisible(true);
       
      
          
    }
   
   
    public static void main(String[] args) {
       
      Evs obj1= new Evs();
     
      obj1.firstframe();
      
      
      
      
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
      
        if(ae.getSource()==badmin) // FOR THE LOGIN OF ADMIN
        {
         
         login lo= new login();
         lo.LOGIN();
         
       
         }
        
        else if (ae.getSource()==bcandidate)  //FOR THE LOGIN OF CANDIDATE
        {
         login lo= new login();
         lo.LOGIN();
          
        }
          else if (ae.getSource()==bvoter)//FOR THE LOGIN OF VOTER 
        {
        login lo= new login();
        lo.LOGIN();
        }

         
       
    }
    

   
}

