
package evs;

import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.spi.DirStateFactory.Result;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class login extends Evs implements ActionListener{
     // THE LOGIN PAGE
    
    
  
    JButton alogin,clogin,vlogin,back1,register;
     JTextField tf1,tf2;
    public void LOGIN()
    {  
      
         
       JLabel lb1,lb2,lb3,lb4;
      
       JFrame f= new JFrame("FOR LOGIN OF USERS");
      
      
       lb1 = new  JLabel();
       lb1.setText("ENTER YOUR ID AND PASSWORD:");
       lb1.setFont(new Font("Ariel Black",Font.BOLD,12));
       lb1.setBounds(24,127,212,30);
       
       lb2 = new  JLabel("USER ID:");
       lb2.setFont(new Font("Ariel Black",Font.BOLD,12));
       lb2.setBounds(30,182,53,17);
       
        tf1 = new  JTextField();
        tf1.setBounds(91, 168, 319, 42);
         
         lb3= new JLabel("PASSWORD:");
         lb3.setFont(new Font("Ariel Black",Font.BOLD,12));
         lb3.setBounds(13, 271,87, 17);
         
          tf2=new JTextField ();
          tf2.setBounds(91,258,319, 42);
         
          
          //ADMIN  LOGIN BUTTON
          alogin= new JButton("ADMIN LOGIN");
          alogin.setBounds(13, 332,150, 40);
          alogin.setBackground(Color.BLUE);
          alogin.setForeground(Color.WHITE);
          alogin.setFocusable(false);
          alogin.addActionListener(this);
          
          // CANDIDATE LOGIN BUTTON
          clogin= new JButton("CANDIDATE LOGIN");
          clogin.setBounds(180, 332,150, 40); 
          clogin.setBackground(Color.BLUE);
          clogin.setForeground(Color.WHITE);
          clogin.setFocusable(false);
          clogin.addActionListener(this);
          
          //VOTER LOGIN BUTTON
          vlogin= new JButton("VOTER LOGIN");
          vlogin.setBounds(350, 332,150, 40);
          vlogin.setBackground(Color.BLUE);
          vlogin.setForeground(Color.WHITE);
          vlogin.setFocusable(false);
          vlogin.addActionListener(this);
          
          // REGISTRATION BUUTON
          register= new JButton("REGISTER");
          register.setBounds(24, 404, 134, 40);
          register.setBackground(Color.BLUE);
          register.setForeground(Color.WHITE);
          register.setFocusable(false);
          register.addActionListener(this);
          
            // THIS BUTTON TAKES YOU TO THE FIRST SCREEN/HOME SCREEN
           back1= new JButton("BACK");
           back1.setBounds(180, 404, 134, 40);
           back1.setBackground(Color.BLUE);
           back1.setForeground(Color.WHITE);
           back1.setFocusable(false);
           back1.addActionListener(this);
          
          
          
       f.setSize(700, 700);
       f.setBackground( new Color(160,186,101));
       f.setVisible(true);
       f.setLayout(null);
       f.setResizable(false);
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       f.add(lb2);
       f.add(lb1);
       f.add(tf1);
       f.add(lb3);
       f.add(tf2);
       f.add(alogin);
       f.add(clogin);
       f.add(vlogin);
       f.add(register);
       f.add(back1);
       
       
       
      
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
     // FOR THE LOGIN OF ADMIN
        
         if(ae.getSource()==alogin)
             
         {
            try
                
            {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/evs","root","");
            String username= tf1.getText();
            String userpassword=tf2.getText();
            Statement stmt= conn.createStatement();
            String sql="select * from admin where name='"+username+"' and password='"+userpassword+"'";
            ResultSet rs = stmt.executeQuery(sql);
            if(rs.next())
                
            {
             admin ad= new admin();
             ad.adminside();
             JOptionPane.showMessageDialog(alogin, " Login Sucessfull");
            }
            
            else
                
            {
                
            JOptionPane.showMessageDialog(alogin, " Login Not Sucessfull");
            tf1.setText(" ");
            tf2.setText(" ");
            }
            
            conn.close();
            }
            
            catch(ClassNotFoundException | SQLException | HeadlessException e)
                
            {
                JOptionPane.showMessageDialog(alogin, e);
               System.out.println("Connection not uccessfull");
            }
                
         }
         
        //FOR THE LOGIN OF CANDIDATE 
         
         
         else if(ae.getSource()==clogin)
             
         {
              try
                  
            {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/evs","root","");
            String username= tf1.getText();
            String userpassword=tf2.getText();
            Statement stmt= conn.createStatement();
            String sql="select * from candidate where name='"+username+"' and password='"+userpassword+"'";
            ResultSet rs = stmt.executeQuery(sql);
            if(rs.next())
                
            {
             candidate cd= new candidate();
             cd.candidateside();
             JOptionPane.showMessageDialog(alogin, " Login Sucessfull");
            }
            
            else
                
            {
            JOptionPane.showMessageDialog(alogin, " Login Not Sucessfull");
            tf1.setText(" ");
            tf2.setText(" ");
            }
            conn.close();
            
            }
            catch(ClassNotFoundException | SQLException | HeadlessException e)
                
            {
                JOptionPane.showMessageDialog(alogin, e);
               System.out.println("Connection not uccessfull");
            }
          
         }
         
         // FOR THE LOGIN OF VOTER
         
         else if(ae.getSource()==vlogin)
             
         {
            try
                
            {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/evs","root","");
            String username= tf1.getText();
            String userpassword=tf2.getText();
            Statement stmt= conn.createStatement();
            String sql="select * from voter where name='"+username+"' and password='"+userpassword+"'";
            ResultSet rs = stmt.executeQuery(sql);
            if(rs.next())
                
            {
                Voter vt= new Voter();
                vt.voterside();
             JOptionPane.showMessageDialog(alogin, " Login Sucessfull");
            }
            
            else
                
            {
            JOptionPane.showMessageDialog(alogin, " Login Not Sucessfull");
            tf1.setText(" ");
            tf2.setText(" ");
            }
            
            conn.close();
            }
            
            catch(ClassNotFoundException | SQLException | HeadlessException e)
                
            {
                JOptionPane.showMessageDialog(alogin, e);
               System.out.println("Connection not uccessfull");
            }  
                 
         }
         // THE REGISTRATION BUTTON
         
         else if (ae.getSource()==register)
         {
       
           register rg = new register();
           rg.REGISTER();
         }
         
         // THIS GOES BACK TO THE FIRST PAGE
         
          else if (ae.getSource()==back1)
         {
       
           Evs obj1= new Evs();
     
           obj1.firstframe();
         }
    
    
    }
}

