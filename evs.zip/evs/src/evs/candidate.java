package evs;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class candidate extends Evs {

    JButton castvote, adddetails, checkres;

    public void candidateside() {
        JMenu file, edit, help;
        JFrame f = new JFrame("THE ADMIN PANEL");
        JMenuBar mb = new JMenuBar();
        file = new JMenu("HOME");
        edit = new JMenu("ABOUT");
        help = new JMenu("HELP");

        adddetails = new JButton("ADD DETAILS");// THE ADD DETAILS BUTTON
        adddetails.setBounds(134, 135, 236, 44);
        adddetails.setFont(new Font("Ariel Black", Font.BOLD, 16));
        adddetails.setBackground(Color.BLUE);
        adddetails.setForeground(Color.WHITE);
        adddetails.setFocusable(false);
        adddetails.addActionListener(this);

        castvote = new JButton("CAST VOTE");// THE CAST VOTE BUTTON
        castvote.setBounds(134, 206, 236, 44);
        castvote.setFont(new Font("Ariel Black", Font.BOLD, 16));
        castvote.setBackground(Color.BLUE);
        castvote.setForeground(Color.WHITE);
        castvote.setFocusable(false);
        castvote.addActionListener(this);

        checkres = new JButton("CHECK RESULTS");// THE CHECK RESULTS BUTTON
        checkres.setBounds(134, 277, 236, 44);
        checkres.setFont(new Font("Ariel Black", Font.BOLD, 16));
        checkres.setBackground(Color.BLUE);
        checkres.setForeground(Color.WHITE);
        checkres.setFocusable(false);
        checkres.addActionListener(this);

        mb.add(file);
        mb.add(edit);
        mb.add(help);
        f.setJMenuBar(mb);

        f.setSize(600, 600);
        f.setVisible(true);
        f.setLayout(null);
        f.setResizable(false);
        f.add(adddetails);
        f.add(castvote);
        f.add(checkres);

    }
    JLabel lb1, lb2, lb3, lb4,lb5;
    JTextField tf1, tf2, tf3, tf4;
    JButton add, clear;

    public void AddDetails() {
        JFrame f;
        f = new JFrame("ADD DETAILS OF CANDIDATE");
        
        lb5 = new JLabel("ADD YOUR DETAILS");
        lb5.setFont(new Font("Ariel Black", Font.BOLD, 13));
        lb5.setBounds(250, 48, 117 , 35);
        f.add(lb5);
        
        lb1 = new JLabel("CNIC:");
        lb1.setFont(new Font("Ariel Black", Font.BOLD, 13));
        lb1.setBounds(117, 137, 60, 14);
        f.add(lb1);

        tf1 = new JTextField();
        tf1.setBounds(195, 128, 278, 32);
        f.add(tf1);

        lb2 = new JLabel("Party Name:");
        lb2.setFont(new Font("Ariel Black", Font.BOLD, 13));
        lb2.setBounds(81, 189, 118, 19);
        f.add(lb2);

        tf2 = new JTextField();
        tf2.setBounds(195, 182, 278, 32);
        f.add(tf2);

        lb3 = new JLabel("Qualification:");
        lb3.setFont(new Font("Ariel Black", Font.BOLD, 13));
        lb3.setBounds(103, 252, 85, 15);
        f.add(lb3);

        tf3 = new JTextField();
        tf3.setBounds(195, 243, 278, 32);
        f.add(tf3);

        lb4 = new JLabel("Age:");
        lb4.setFont(new Font("Ariel Black", Font.BOLD, 13));
        lb4.setBounds(147, 315, 35, 15);
        f.add(lb4);

        tf4 = new JTextField();
        tf4.setBounds(195, 311, 278, 32);
        f.add(tf4);

        add = new JButton("ADD");
        add.setBounds(211, 389, 97, 30);
        add.setBackground(Color.BLUE);
        add.setForeground(Color.WHITE);
        add.setFocusable(false);
        add.addActionListener(this);
        f.add(add);

        clear = new JButton("CLEAR");
        clear.setBounds(350, 389, 97, 30);
        clear.setBackground(Color.BLUE);
        clear.setForeground(Color.WHITE);
        clear.setFocusable(false);
        clear.addActionListener(this);
        f.add(clear);
        f.setSize(700, 700);
        f.setLayout(null);
        f.setVisible(true);



    }
    
    JFrame f;
    JLabel l1, l2, l3, l4;
    JTextField t1, t2;
    JButton b1;
    JRadioButton rb1, rb2, rb3;

    public void CastVote() {
        f = new JFrame();
        f.setSize(600, 600);
        f.setBackground(Color.decode("#787474"));

        l1 = new JLabel();
        l1.setText("ONLINE VOTING SYSTEM");
        Font font = new Font("Courier", Font.BOLD, 30);
        Font font1 = new Font("Courier", Font.BOLD, 15);
        l1.setFont(font);
        l1.setBounds(100, -100, 500, 300);
        f.add(l1);

        l2 = new JLabel();
        l2.setText("ENTER NAME");
        l2.setBounds(20, 50, 200, 200);
        l2.setFont(font1);
        f.add(l2);

        l3 = new JLabel();
        l3.setText("ENTER CNIC");
        l3.setBounds(20, 120, 200, 200);
        l3.setFont(font1);
        f.add(l3);

        JTextField t1 = new JTextField();
        t1.setBounds(180, 130, 300, 40);
        t1.setBackground(Color.decode("#FFFAF6"));
        f.add(t1);

        JTextField t2 = new JTextField();
        t2.setBounds(180, 200, 300, 40);
        t2.setBackground(Color.decode("#FFFAF6"));
        f.add(t2);

        l4 = new JLabel();
        l4.setText("CAST YOUR VOTE HERE");
        l4.setBounds(20, 200, 300, 200);
        l4.setFont(font1);
        f.add(l4);

        rb1 = new JRadioButton("PARTY A");
        rb2 = new JRadioButton("PARTY B");
        rb3 = new JRadioButton("PARTY C");

        rb1.setBounds(20, 340, 80, 30);
        rb2.setBounds(20, 370, 80, 30);
        rb3.setBounds(20, 400, 80, 30);

        ButtonGroup G1 = new ButtonGroup();
        G1.add(rb1);
        G1.add(rb2);
        G1.add(rb3);


        f.add(rb1);
        f.add(rb2);
        f.add(rb3);


        b1 = new JButton("SUBMIT YOUR VOTE");
        b1.setBounds(220, 370, 230, 30);
        b1.setBackground(Color.BLUE);
        b1.setForeground(Color.WHITE);
        f.add(b1);

        f.setLayout(null);
        f.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == castvote) // CALLING CAST VOTE BUTTON
        {
            candidate cd = new candidate();
            cd.CastVote();
        } 
        else if (ae.getSource() == adddetails) // CALLING ADD DETAILS BUTTON
        {
            candidate cd = new candidate();
            cd.AddDetails();
        } else if (ae.getSource() == add) {

            try {

                String cnic = tf1.getText();
                String party = tf2.getText();
                String qual = tf3.getText();
                String age = tf4.getText().toString();


                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/evs", "root", "");
                String sql = "INSERT INTO candetails(`cnic`, `partyname`, `qualification`, `age`)"
                        + "value('" + cnic + "','" + party + "','" + qual + "','" + age + "')";

                PreparedStatement ptst = conn.prepareStatement(sql);


                int count = ptst.executeUpdate();

                conn.close();

                JOptionPane.showMessageDialog(add, "added successfully");
            } 
            
                catch (ClassNotFoundException | SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(add, e);
                System.out.println("Connection not successfull");
            }

        }

          else if(ae.getSource()==clear) // TO CLEAR THE REGISTRATION FORM
      {
          tf1.setText(" ");
          tf2.setText(" ");
          tf3.setText(" ");
          tf4.setText(" ");
          
            
      }
    }
}
