
package evs;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;

import javax.swing.JTextField;




public class admin extends Evs implements ActionListener   
{  //ADMIN'sMAIN SCREEN
    
    JButton btt1,btt2,btt3,btt4,btt5,btt6,btt7;
    
  public void adminside()
    {
        
         
        
          JMenu file,edit,help;  
          JFrame f= new JFrame("THE ADMIN PANEL");  
          JMenuBar mb=new JMenuBar();  
           file=new JMenu("HOME");    
           edit=new JMenu("ABOUT");    
           help=new JMenu("HELP");
           
       //THE VERIFY CANDIDATE BUTTON
       btt1= new JButton("VERIFY CANDIDATE");
       btt1.setBounds(233,167,219,37);
       btt1.setFont(new Font("Ariel Black",Font.BOLD,16));
       btt1.setBackground(Color.BLUE);
       btt1.setForeground(Color.WHITE);
       btt1.setFocusable(false);
       btt1.addActionListener(this);
       
       //THE VERIFY VOTER BUTTON
       btt2= new JButton("VERIFY VOTER");
       btt2.setBounds(233,219,219,37);
       btt2.setFont(new Font("Ariel Black",Font.BOLD,16));
       btt2.setBackground(Color.BLUE);
       btt2.setForeground(Color.WHITE);
       btt2.setFocusable(false);
       btt2.addActionListener(this);
       
       //CHECK CANDIDATE'S DETAILS 
       btt3= new JButton("CHECK CANDIDATE DETAILS");
       btt3.setBounds(233,271,219,37);
       btt3.setFont(new Font("Ariel Black",Font.BOLD,13));
       btt3.setBackground(Color.BLUE);
       btt3.setForeground(Color.WHITE);
       btt3.setFocusable(false);
       btt3.addActionListener(this);
       
       //CHECK VOTER'S DETAILS 
       btt4= new JButton("CHECK VOTER DETAILS");
       btt4.setBounds(233,323,219,37);
       btt4.setFont(new Font("Ariel Black",Font.BOLD,13));
       btt4.setBackground(Color.BLUE);
       btt4.setForeground(Color.WHITE);
       btt4.setFocusable(false);
       btt4.addActionListener(this);
       
     //DELETE CANDIDATE
       btt5= new JButton("DELETE CANDIDATE");
       btt5.setBounds(233,375,219,37);
       btt5.setFont(new Font("Ariel Black",Font.BOLD,16));
       btt5.setBackground(Color.BLUE);
       btt5.setForeground(Color.WHITE);
       btt5.setFocusable(false);
       btt5.addActionListener(this);
       
       //DELETE VOTER  BUTTON
       btt6= new JButton(" DELETE VOTER");
       btt6.setBounds(233,427,219,37);
       btt6.setFont(new Font("Ariel Black",Font.BOLD,16));
       btt6.setBackground(Color.BLUE);
       btt6.setForeground(Color.WHITE);
       btt6.setFocusable(false);
       btt6.addActionListener(this);
       
      
       
       
       //CHECK RESULTS BUTTON
    
       btt7= new JButton("CHECK RESULTS");
       btt7.setBounds(233,479,219,37);
       btt7.setFont(new Font("Ariel Black",Font.BOLD,16));
       btt7.setBackground(Color.BLUE);
       btt7.setForeground(Color.WHITE);
       btt7.setFocusable(false);
       btt7.addActionListener(this);
       
           
          mb.add(file); 
          mb.add(edit);  
          mb.add(help);  
          f.setJMenuBar(mb); 
          f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          f.setSize(700,700);  
          f.setLayout(null);  
          f.setVisible(true);
          f.add(btt1);
          f.add(btt2);
          f.add(btt3);
          f.add(btt4);
          f.add(btt5);
          f.add(btt6);
          f.add(btt7);
         
    }
  
  // THE VERIFY CANDIDATE BUTTON
  
    JButton verifycan,back;
  public void VerifyCandidate() 
      
     {
     
      JLabel l,l1;
      JTextField cnic;
      
      
      Frame f=new JFrame("TO VERIFY CANDIDATE");
      f.setSize(700,700);
      f.setBackground(Color.decode("#787474"));
      l=new JLabel("Verify Candidate");
          
       Font font=new Font("Courier",Font.BOLD,26);
       l.setFont(font);
       l.setBounds(190,10,300,300);
       f.add(l);
       
       l1=new JLabel();
       l1.setText("ENTER CNIC:");
       l1.setBounds(50,200,100,100);
       f.add(l1 );
       cnic=new JTextField();
       cnic.setBounds(150,230,400,36);
       f.add(cnic);
       
       // VERIFICATION OF CANDIDATE
       verifycan=new JButton("VERIFY");
       verifycan.setBounds(190,320,120,50);
       verifycan.setBackground(Color.BLUE);
       verifycan.setForeground(Color.WHITE);
       verifycan.addActionListener(this);
       f.add(verifycan);
       
       back=new JButton("BACK");
       back.setBounds(380,320,120,50);
       back.setBackground(Color.BLUE);
       back.setForeground(Color.WHITE);
       back.addActionListener(this);
       f.add(back);
       f.setLayout(null);
       f.setVisible(true);
  
      }
  
  // THE VERIFY VOTER BUTTON
  
  
  JButton verifyvot,back1;
  public void VerifyVoter() 
      
     {
     
      JLabel l,l1;
      JTextField cnic;
      
      
      Frame f=new JFrame("TO VERIFY VOTER");
      f.setSize(700,700);
      f.setBackground(Color.decode("#787474"));
      l=new JLabel("Verify Voter");
          
       Font font=new Font("Courier",Font.BOLD,26);
       l.setFont(font);
       l.setBounds(190,10,300,300);
       f.add(l);
       
       l1=new JLabel();
       l1.setText("ENTER CNIC:");
       l1.setBounds(50,200,100,100);
       f.add(l1 );
       cnic=new JTextField();
       cnic.setBounds(150,230,400,36);
       f.add(cnic);
     
       // VERIFICATION OF VOTER
       
       verifyvot=new JButton("VERIFY");
       verifyvot.setBounds(190,320,120,50);
       verifyvot.setBackground(Color.BLUE);
       verifyvot.setForeground(Color.WHITE);
       verifyvot.addActionListener(this);
       f.add(verifyvot);
       
       
       back1=new JButton("BACK");
       back1.setBounds(380,320,120,50);
       back1.setBackground(Color.BLUE);
       back1.setForeground(Color.WHITE);
       back1.addActionListener(this);
       f.add(back1);
      
       f.setLayout(null);
       f.setVisible(true);
  
      }
  
  
  // THE DELETE CANDIDATE BUTTON
   JTextField ttf;
  JButton deletecan,back2;
  public void DeleteCandidate() 
      
     {
     
      JLabel l,l1;
    
      Frame f=new JFrame(" TO DELETE THE CANDIDATE ");
      f.setSize(700,700);
      f.setBackground(Color.decode("#787474"));
      l=new JLabel("Delete Candidate");
          
       Font font=new Font("Courier",Font.BOLD,26);
       l.setFont(font);
       l.setBounds(190,10,300,300);
       f.add(l);
       
       l1=new JLabel();
       l1.setText("ENTER CNIC:");
       l1.setBounds(50,200,100,100);
       f.add(l1 );
       ttf=new JTextField();
       ttf.setBounds(150,230,400,36);
       f.add(ttf);
       
       // DELETE CANDIDATE
       deletecan=new JButton("DELETE");
       deletecan.setBounds(190,320,120,50);
       deletecan.setBackground(Color.BLUE);
       deletecan.setForeground(Color.WHITE);
       deletecan.addActionListener(this);
       f.add(deletecan);
       
       back2=new JButton("BACK");
       back2.setBounds(380,320,120,50);
       back2.setBackground(Color.BLUE);
       back2.setForeground(Color.WHITE);
       back2.addActionListener(this);
       f.add(back2);
       f.setLayout(null);
       f.setVisible(true);
  
      }
  
  
  // THE DELETE VOTER BUTTON
   JButton deletevot,back3;
  public void DeleteVoter() 
      
     {
     
      JLabel l,l1;
      JTextField t;
      
      
      Frame f=new JFrame(" TO DELETE THE VOTER");
      f.setSize(700,700);
      f.setBackground(Color.decode("#787474"));
      l=new JLabel("Delete Voter");
          
       Font font=new Font("Courier",Font.BOLD,26);
       l.setFont(font);
       l.setBounds(190,10,300,300);
       f.add(l);
       
       l1=new JLabel();
       l1.setText("ENTER CNIC:");
       l1.setBounds(50,200,100,100);
       f.add(l1 );
       t=new JTextField();
       t.setBounds(150,230,400,36);
       f.add(t);
       
       // DELETE VOTER
       deletevot=new JButton("DELETE");
       deletevot.setBounds(190,320,120,50);
       deletevot.setBackground(Color.BLUE);
       deletevot.setForeground(Color.WHITE);
       deletevot.addActionListener(this);
       f.add(deletevot);
       
       back3=new JButton("BACK");
       back3.setBounds(380,320,120,50);
       back3.setBackground(Color.BLUE);
       back3.setForeground(Color.WHITE);
       back3.addActionListener(this);
       f.add(back3);
       f.setLayout(null);
       f.setVisible(true);
  
      }
    public void CheckCandidateDetails()
    {
           
    }
    
    
  
  
   @Override
    public void actionPerformed(ActionEvent ae) 
   {
        if(ae.getSource()==btt1)  // CALLING VERIFY CANDIDATE BUTTON
       {
           admin ad= new admin();
           ad.VerifyCandidate();
       }
        
        
          else if(ae.getSource()==back) // THE BACK BUTTON 
       {
       admin ad = new admin();
       ad.adminside();
       }
          
        else  if(ae.getSource()==btt2) // CALLING VERIFY VOTER BUTTON
       {
           admin ad= new admin();
           ad.VerifyVoter();
       }
        
       else if(ae.getSource()==back1)
       {
       admin ad = new admin();
       ad.adminside();
       }
       
       
         else  if(ae.getSource()==btt5) // CALLING DELETE CANDIDATE BUUTON
       {
           admin ad= new admin();
           ad.DeleteCandidate();
       }
         
         
         
         
            else  if(ae.getSource()==deletecan) //  DELETE CANDIDATE 
       {  
               try
                
            {
                try
                {
                  Class.forName("com.mysql.jdbc.Driver");  
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                String temp= ttf.getText().toString();
            //int cnic= Integer.parseInt(ttf.getText());
            Connection conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/evs","root","");
            System.out.println("connection sucessfull");
            String sql="delete  from candidate where cnic="+temp;
            Statement stmt= conn.createStatement();
           int row=stmt.executeUpdate(sql);
        
            if(row>0)
                
            {
           
             JOptionPane.showMessageDialog(deletecan, " Deleted Successfully");
            }
            
          else    
            {
                
            JOptionPane.showMessageDialog(deletecan, " Record Not Found");
            ttf.setText(" ");
            }
       
            conn.close();
            }
               
            catch(SQLException e)
                
            {
               
               System.out.println(e);
            }
               
       }
         
         
       else if(ae.getSource()==back2)
       {
       admin ad = new admin();
       ad.adminside();
       }
   
        
       else  if(ae.getSource()==btt6) // CALLING DELETE VOTER BUUTON
       {
           admin ad= new admin();
           ad.DeleteVoter();
       }
         
         
       else if(ae.getSource()==back3)
       {
       admin ad = new admin();
       ad.adminside();
       }
           }
}
 

        
   
    

