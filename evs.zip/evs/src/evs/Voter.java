
package evs;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Voter extends Evs {

    JButton B1,B2,B3;
    public void voterside()
    {
       JFrame f= new JFrame("THE VOTER PANEL");  
         
        
      B1= new JButton ("CHECK CANDIDATE LIST");// THE CHECK CANDIDATE LIST BUTTON
      B1.setBounds(134,135,236,44);
      B1.setFont(new Font("Ariel Black",Font.BOLD,16));
      B1.setBackground(Color.BLUE);
      B1.setForeground(Color.WHITE);
      B1.setFocusable(false);
      B1.addActionListener(this);
      
      B2= new JButton ("CAST VOTE");// THE CAST VOTE BUTTON
      B2.setBounds(134,206,236,44);
      B2.setFont(new Font("Ariel Black",Font.BOLD,16));
      B2.setBackground(Color.BLUE);
      B2.setForeground(Color.WHITE);
      B2.setFocusable(false);
      B2.addActionListener(this);
      
      B3= new JButton ("CHECK RESULTS");// THE CHECK RESULTS BUTTON
      B3.setBounds(134,277,236,44);
      B3.setFont(new Font("Ariel Black",Font.BOLD,16));
      B3.setBackground(Color.BLUE);
      B3.setForeground(Color.WHITE);
      B3.setFocusable(false);
      B3.addActionListener(this);
       
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.setSize(600,600);
      f.setVisible(true);
      f.setLayout(null);
      f.setResizable(false);
      f.add(B1);
      f.add(B2);
      f.add(B3);
      
    }
    
    // THE CAST VOTE BUTTON
      JFrame f;
    JLabel l1, l2, l3, l4;
    JTextField t1, t2;
    JButton b1;
    JRadioButton rb1, rb2, rb3;

    public void CastVote() {
        f = new JFrame();
        f.setSize(600, 600);
        f.setBackground(Color.decode("#787474"));

        l1 = new JLabel();
        l1.setText("ONLINE VOTING SYSTEM");
        Font font = new Font("Courier", Font.BOLD, 30);
        Font font1 = new Font("Courier", Font.BOLD, 15);
        l1.setFont(font);
        l1.setBounds(100, -100, 500, 300);
        f.add(l1);

        l2 = new JLabel();
        l2.setText("ENTER NAME");
        l2.setBounds(20, 50, 200, 200);
        l2.setFont(font1);
        f.add(l2);

        l3 = new JLabel();
        l3.setText("ENTER CNIC");
        l3.setBounds(20, 120, 200, 200);
        l3.setFont(font1);
        f.add(l3);

        JTextField t1 = new JTextField();
        t1.setBounds(180, 130, 300, 40);
        t1.setBackground(Color.decode("#FFFAF6"));
        f.add(t1);

        JTextField t2 = new JTextField();
        t2.setBounds(180, 200, 300, 40);
        t2.setBackground(Color.decode("#FFFAF6"));
        f.add(t2);

        l4 = new JLabel();
        l4.setText("CAST YOUR VOTE HERE");
        l4.setBounds(20, 200, 300, 200);
        l4.setFont(font1);
        f.add(l4);

        rb1 = new JRadioButton("PARTY A");
        rb2 = new JRadioButton("PARTY B");
        rb3 = new JRadioButton("PARTY C");

        rb1.setBounds(20, 340, 80, 30);
        rb2.setBounds(20, 370, 80, 30);
        rb3.setBounds(20, 400, 80, 30);

        ButtonGroup G1 = new ButtonGroup();
        G1.add(rb1);
        G1.add(rb2);
        G1.add(rb3);


        f.add(rb1);
        f.add(rb2);
        f.add(rb3);


        b1 = new JButton("SUBMIT YOUR VOTE");
        b1.setBounds(220, 370, 230, 30);
        b1.setBackground(Color.BLUE);
        b1.setForeground(Color.WHITE);
        f.add(b1);

        f.setLayout(null);
        f.setVisible(true);
    }
          @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() ==B2) // CALLING CAST VOTE BUTTON
        {
            candidate cd = new candidate();
            cd.CastVote();
        } 
          }
    }
    
   
      
