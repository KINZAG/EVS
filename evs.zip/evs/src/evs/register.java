
package evs;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class register extends Evs implements ActionListener {
    
    //THE REGISTRATION FORM
    JButton submit, clear, back;
    JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8;
    public void REGISTER()
    {
    
        JLabel lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8,lb9;
       
       JFrame f= new JFrame("REGISTRATION FORM FOR USERS");
      
       lb1 = new  JLabel();
       lb1.setText("REGISTRATION FORM:");
       lb1.setFont(new Font("Ariel Black",Font.BOLD,13));
       lb1.setBounds(200,41,144,19);
       
       lb2 = new  JLabel("NAME:");
       lb2.setFont(new Font("Ariel Black",Font.BOLD,13));
       lb2.setBounds(98,120,50,19);
       
       tf1 = new  JTextField();
       tf1.setBounds(178,114, 260,30);
         
        lb3= new JLabel("FATHER'S NAME:");
        lb3.setFont(new Font("Ariel Black",Font.BOLD,13));
        lb3.setBounds(27, 170,118, 19);
         
        tf2=new JTextField ();
        tf2.setBounds(178,164,260, 30);
        
        lb4 =new JLabel("DOB:");
        lb4.setFont(new Font("Ariel Black",Font.BOLD,13));
        lb4.setBounds(106, 220,40, 19);
         
        tf3=new JTextField ();
        tf3.setBounds(178,214,260, 30);
        
        lb5 =new JLabel("CNIC:");
        lb5.setFont(new Font("Ariel Black",Font.BOLD,13));
        lb5.setBounds(100, 270,46, 19);
         
        tf4=new JTextField ();
        tf4.setBounds(178,264,260, 30);
        
        lb6 =new JLabel("PHONE NUMBER:");
        lb6.setFont(new Font("Ariel Black",Font.BOLD,13));
        lb6.setBounds(24, 325,121, 19);
         
        tf5 =new JTextField ();
        tf5.setBounds(178,315,260, 30);
        
        lb7 =new JLabel("RELIGION:");
        lb7.setFont(new Font("Ariel Black",Font.BOLD,13));
        lb7.setBounds(77, 375,68, 19);
         
        tf6 =new JTextField ();
        tf6.setBounds(178,365,260, 30);
        
        lb8 =new JLabel("EMAIL ADDRESS:");
        lb8.setFont(new Font("Ariel Black",Font.BOLD,13));
        lb8.setBounds(27, 421,117, 19);
         
        tf7 =new JTextField ();
        tf7.setBounds(178,416,260, 30);
        
        lb9 =new JLabel("PASSWORD:");
        lb9.setFont(new Font("Ariel Black",Font.BOLD,13));
        lb9.setBounds(59, 471,82, 19);
         
        tf8 =new JTextField ();
        tf8.setBounds(178,466,260, 30);
        
      // THE SUBMIT BUTTON
          submit= new JButton("SUBMIT");
          submit.setBounds(181, 533, 102, 33);
          submit.setBackground(Color.BLUE);
          submit.setForeground(Color.WHITE);
          submit.setFocusable(false);
          submit.addActionListener(this);
          
        // THE CLEAR BUTTON
          clear= new JButton("CLEAR");
          clear.setBounds(308, 533, 102, 33);
          clear.setBackground(Color.BLUE);
          clear.setForeground(Color.WHITE);
          clear.setFocusable(false);
          clear.addActionListener(this);
          
          // THE BACK BUTTON
          back= new JButton("BACK");
          back.setBounds(438, 533, 102, 33);
          back.setBackground(Color.BLUE);
          back.setForeground(Color.WHITE);
          back.setFocusable(false);
          back.addActionListener(this);
        
        
          
       f.setSize(750, 750);
       f.setVisible(true);
       f.setLayout(null);
       f.setResizable(false);
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       f.add(lb1);
       f.add(lb2);
       f.add(tf1);
       f.add(lb3);
       f.add(tf2);
       f.add(lb4);
       f.add(tf3);
       f.add(lb5);
       f.add(tf4);
       f.add(lb6);
       f.add(tf5);
       f.add(lb7);
       f.add(tf6);
       f.add(lb8);
       f.add(tf7);
       f.add(lb9);
       f.add(tf8);
       f.add(submit);
       f.add(clear);
       f.add(back);
      
      
    }
    @Override
    public void actionPerformed(ActionEvent ae)
    {
      if(ae.getSource()==submit ) // FOR REGISTRATION OF USERW
         {
           
       try
           { 
               
               String name=tf1.getText();
               String fname=tf2.getText();
               String dob=tf3.getText();
               String cnic=tf4.getText().toString();
               String phnum=tf5.getText();
               String religion=tf6.getText();
               String email=tf7.getText();
               String password=tf8.getText();
              
               
          Class.forName("com.mysql.jdbc.Driver");
         Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/evs","root","");
           String sql="INSERT INTO candidate (`name`, `fname`, `dob`, `cnic`, `phnum`, `religion`, `email`, `password`)"
           +"value('"+name+"','"+fname+"','"+dob+"','"+cnic+"','"+phnum+"','"+religion+"','"+email+"','"+password+"')";
                 
           PreparedStatement ptst= conn.prepareStatement(sql);
           //ptst.setString(1,"2");

           int count= ptst.executeUpdate();
          
           System.out.println("inseted successfully");
           conn.close();
           JOptionPane.showMessageDialog(submit, "inserted successfully");
           }
           
           catch(ClassNotFoundException | SQLException | HeadlessException e)
           {
               JOptionPane.showMessageDialog(submit, e);
               System.out.println("Connection not successfull");
           }
             
             
         }
      
      
      else  if(ae.getSource()==submit) // FOR REGISTRATION OF USERW
         {
             //Connection conn= null;
         
          
           try
           { 
               String name=tf1.getText();
               String fname=tf2.getText();
               String dob=tf3.getText();
               String cnic=tf4.getText();
               String phnum=tf5.getText();
               String religion=tf6.getText();
               String email=tf7.getText();
               String password=tf8.getText();
              
               
          Class.forName("com.mysql.jdbc.Driver");
         Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/evs","root","");
           String sql="INSERT INTO candidate (`name`, `fname`, `dob`, `cnic`, `phnum`, `religion`, `email`, `password`)"
           +"value('"+name+"','"+fname+"','"+dob+"','"+cnic+"','"+phnum+"','"+religion+"','"+email+"','"+password+"')";
                 
           PreparedStatement ptst= conn.prepareStatement(sql);
           //ptst.setString(1,"2");

           int count= ptst.executeUpdate();
          
           System.out.println("inseted successfully");
           conn.close();
           JOptionPane.showMessageDialog(submit, "inserted successfully");
           }
           
           catch(ClassNotFoundException | SQLException | HeadlessException e)
           {
               JOptionPane.showMessageDialog(submit, e);
               System.out.println("Connection not successfull");
           }
             
             
         }
      
      
      else if(ae.getSource()==clear) // TO CLEAR THE REGISTRATION FORM
      {
          tf1.setText(" ");
          tf2.setText(" ");
          tf3.setText(" ");
          tf4.setText(" ");
          tf5.setText(" ");
          tf6.setText(" ");
          tf7.setText(" ");
          tf8.setText(" ");
            
      }
      
      else if(ae.getSource()==back)
      {
          Evs obj1= new Evs();
          obj1.firstframe();
      }
      
      
      
      else
          
      {
           JOptionPane.showMessageDialog(submit, "registration failed");
      }
          
      
}
    
}